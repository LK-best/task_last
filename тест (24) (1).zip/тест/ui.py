from pyqtgraph import PlotWidget
from PyQt6 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(800, 600)
        self.centralwidget = QtWidgets.QWidget(parent=MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        
        # График
        self.graphicsView = PlotWidget(parent=self.centralwidget)
        self.graphicsView.setGeometry(QtCore.QRect(230, 50, 500, 400))
        self.graphicsView.setObjectName("graphicsView")
        
        # Кнопка для отрисовки
        self.pushButton = QtWidgets.QPushButton(parent=self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(440, 480, 150, 30))
        self.pushButton.setObjectName("pushButton")
        
        # --- ДОБАВЛЕНО: Radio Buttons ---
        self.radioButton = QtWidgets.QRadioButton(parent=self.centralwidget)
        self.radioButton.setGeometry(QtCore.QRect(50, 100, 150, 20))
        self.radioButton.setObjectName("radioButton")
        self.radioButton.setChecked(True) # Выбран по умолчанию

        self.radioButton_2 = QtWidgets.QRadioButton(parent=self.centralwidget)
        self.radioButton_2.setGeometry(QtCore.QRect(50, 130, 150, 20))
        self.radioButton_2.setObjectName("radioButton_2")

        self.radioButton_3 = QtWidgets.QRadioButton(parent=self.centralwidget)
        self.radioButton_3.setGeometry(QtCore.QRect(50, 160, 150, 20))
        self.radioButton_3.setObjectName("radioButton_3")
        # --------------------------------

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(parent=MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 21))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(parent=MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Графики функций"))
        self.pushButton.setText(_translate("MainWindow", "Построить график"))
        self.radioButton.setText(_translate("MainWindow", "y = x (Линейная)"))
        self.radioButton_2.setText(_translate("MainWindow", "y = x² (Парабола)"))
        self.radioButton_3.setText(_translate("MainWindow", "y = x³ (Кубическая)"))